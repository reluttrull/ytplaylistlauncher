Current package at: https://test.pypi.org/project/ytplaylistlauncher/

<img width="600" alt="image" src="https://github.com/user-attachments/assets/bee5319c-16c0-42a1-aa9a-45957d3c0bde" />

<img width="600" alt="image" src="https://github.com/user-attachments/assets/aa2a462a-2b19-4767-99d9-07e8dc9c3590" />
